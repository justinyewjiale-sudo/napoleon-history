# 拿破仑历史人物网站

## 打开方法
1. 解压网站文件夹。
2. 双击 `index.html`，即可在浏览器中打开。

## 文件结构
- `index.html`：网站主页
- `assets/styles.css`：页面样式
- `assets/app.js`：导航、动画、音频与交互
- `assets/napoleon-portrait.jpg`：人物图片
- `assets/battle-horn.mp3`：出征号角音频

网站不依赖外部框架，可离线浏览，也可上传至 GitHub Pages、Netlify、学校服务器或一般网页空间。
