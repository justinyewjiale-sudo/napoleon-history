const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

window.addEventListener('load', () => {
  window.setTimeout(() => $('#loading')?.classList.add('is-hidden'), 450);
});

const navToggle = $('#navToggle');
const siteNav = $('#siteNav');
navToggle?.addEventListener('click', () => {
  const open = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', String(!open));
  navToggle.classList.toggle('is-open', !open);
  siteNav?.classList.toggle('is-open', !open);
});
$$('#siteNav a').forEach(link => link.addEventListener('click', () => {
  navToggle?.setAttribute('aria-expanded', 'false');
  navToggle?.classList.remove('is-open');
  siteNav?.classList.remove('is-open');
}));

document.addEventListener('click', (event) => {
  if (!siteNav?.contains(event.target) && !navToggle?.contains(event.target)) {
    navToggle?.setAttribute('aria-expanded', 'false');
    navToggle?.classList.remove('is-open');
    siteNav?.classList.remove('is-open');
  }
});

const progress = $('#readingProgress');
const backToTop = $('#backToTop');
const updateScrollUI = () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const percent = max > 0 ? (window.scrollY / max) * 100 : 0;
  if (progress) progress.style.width = `${percent}%`;
  backToTop?.classList.toggle('is-visible', window.scrollY > 650);
};
window.addEventListener('scroll', updateScrollUI, { passive: true });
updateScrollUI();
backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -30px' });
$$('.reveal').forEach((item, index) => {
  item.style.transitionDelay = `${Math.min(index % 4, 3) * 55}ms`;
  revealObserver.observe(item);
});

const sectionLinks = $$('#siteNav a');
const observedSections = sectionLinks.map(link => $(link.getAttribute('href'))).filter(Boolean);
const navObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      sectionLinks.forEach(link => link.classList.toggle('is-active', link.getAttribute('href') === `#${entry.target.id}`));
    }
  });
}, { rootMargin: '-35% 0px -55%', threshold: 0 });
observedSections.forEach(section => navObserver.observe(section));

const audio = $('#battleAudio');
const audioButton = $('#audioButton');
const audioLabel = $('#audioLabel');
const audioIcon = $('.audio-button__icon');
const setAudioState = (playing) => {
  audioButton?.classList.toggle('is-playing', playing);
  if (audioLabel) audioLabel.textContent = playing ? '暂停《出征号角》' : '播放《出征号角》';
  if (audioIcon) audioIcon.textContent = playing ? 'Ⅱ' : '▶';
  audioButton?.setAttribute('aria-label', playing ? '暂停出征号角' : '播放出征号角');
};
audioButton?.addEventListener('click', async () => {
  if (!audio) return;
  try {
    if (audio.paused) await audio.play(); else audio.pause();
  } catch (error) {
    if (audioLabel) audioLabel.textContent = '浏览器未能播放音频';
  }
});
audio?.addEventListener('play', () => setAudioState(true));
audio?.addEventListener('pause', () => setAudioState(false));
audio?.addEventListener('ended', () => setAudioState(false));

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const canvas = $('#particleCanvas');
if (canvas && !reducedMotion) {
  const ctx = canvas.getContext('2d');
  let width = 0;
  let height = 0;
  let particles = [];
  const count = Math.min(70, Math.max(34, Math.floor(window.innerWidth / 18)));

  const resize = () => {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 1.4 + .4,
      vx: (Math.random() - .5) * .18,
      vy: (Math.random() - .5) * .18,
      a: Math.random() * .38 + .08
    }));
  };

  const draw = () => {
    ctx.clearRect(0, 0, width, height);
    particles.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = width; if (p.x > width) p.x = 0;
      if (p.y < 0) p.y = height; if (p.y > height) p.y = 0;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(97,153,236,${p.a})`; ctx.fill();
      for (let j = i + 1; j < particles.length; j++) {
        const q = particles[j];
        const dx = p.x - q.x; const dy = p.y - q.y;
        const distance = Math.hypot(dx, dy);
        if (distance < 110) {
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(97,153,236,${.07 * (1 - distance / 110)})`;
          ctx.stroke();
        }
      }
    });
    requestAnimationFrame(draw);
  };
  resize(); draw();
  window.addEventListener('resize', resize, { passive: true });
}

const glow = $('#cursorGlow');
if (glow && !reducedMotion && window.matchMedia('(pointer:fine)').matches) {
  let tx = innerWidth / 2, ty = innerHeight / 2, x = tx, y = ty;
  window.addEventListener('pointermove', event => { tx = event.clientX; ty = event.clientY; }, { passive: true });
  const follow = () => {
    x += (tx - x) * .11; y += (ty - y) * .11;
    glow.style.left = `${x}px`; glow.style.top = `${y}px`;
    requestAnimationFrame(follow);
  };
  follow();
}
